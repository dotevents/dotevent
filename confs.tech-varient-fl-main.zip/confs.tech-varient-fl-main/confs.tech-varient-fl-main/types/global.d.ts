export type SortBy = 'startDate' | 'cfpEndDate'
export type SortDirection = 'asc' | 'desc'
