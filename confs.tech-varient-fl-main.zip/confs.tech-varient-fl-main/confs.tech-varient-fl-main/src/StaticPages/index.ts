import AboutPage from './AboutPage'
import NotFoundPage from './NotFoundPage'

export { AboutPage, NotFoundPage }
