export { default } from './OpenCollectiveContribution'
