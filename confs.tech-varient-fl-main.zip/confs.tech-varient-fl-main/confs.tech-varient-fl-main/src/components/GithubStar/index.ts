export { default } from './GithubStar'
