export { default } from './Heading'
