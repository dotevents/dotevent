export { default } from './Divider'
