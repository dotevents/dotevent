import styles from './Divider.module.scss'

export default function Divider() {
  return <hr className={styles.Divider} />
}
