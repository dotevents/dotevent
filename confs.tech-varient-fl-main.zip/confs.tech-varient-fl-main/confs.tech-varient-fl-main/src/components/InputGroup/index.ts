export { default } from './InputGroup'
