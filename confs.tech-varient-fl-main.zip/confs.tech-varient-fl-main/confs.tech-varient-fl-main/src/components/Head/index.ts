export { default } from './Head'
