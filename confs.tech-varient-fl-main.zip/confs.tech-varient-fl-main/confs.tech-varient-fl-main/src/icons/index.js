export { default as loading } from './loading.svg'
